"""ART AI secure backend: single images and manga pages."""
import base64
import os
import time
import uuid
from collections import defaultdict, deque
from pathlib import Path
from typing import Deque

from fastapi import FastAPI, HTTPException, Request
from fastapi.staticfiles import StaticFiles
from openai import AsyncOpenAI
from pydantic import BaseModel, Field

APP_DIR = Path(__file__).resolve().parent
GENERATED_DIR = APP_DIR / "generated"
GENERATED_DIR.mkdir(exist_ok=True)

app = FastAPI(title="ART AI API", version="2.0.0")
app.mount("/generated", StaticFiles(directory=str(GENERATED_DIR)), name="generated")

class GenerateRequest(BaseModel):
    prompt: str = Field(min_length=3, max_length=2000)
    style: str = Field(min_length=1, max_length=80)

class MangaRequest(BaseModel):
    story: str = Field(min_length=10, max_length=1800)
    character: str = Field(min_length=3, max_length=700)
    style: str = Field(default="مانجا يابانية أبيض وأسود", min_length=1, max_length=100)
    page_count: int = Field(default=3, ge=1, le=4)

class GenerateResponse(BaseModel):
    image_url: str

class MangaResponse(BaseModel):
    pages: list[str]

_requests: dict[str, Deque[float]] = defaultdict(deque)
WINDOW_SECONDS = 60
MAX_REQUESTS_PER_WINDOW = 3

def enforce_rate_limit(client_ip: str) -> None:
    now = time.time()
    bucket = _requests[client_ip]
    while bucket and now - bucket[0] > WINDOW_SECONDS:
        bucket.popleft()
    if len(bucket) >= MAX_REQUESTS_PER_WINDOW:
        raise HTTPException(status_code=429, detail="طلبات كثيرة. حاول بعد دقيقة.")
    bucket.append(now)

def get_client() -> AsyncOpenAI:
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        raise HTTPException(status_code=503, detail="الخادم لم يُعدّ بمفتاح OpenAI بعد. اطلب من مسؤول الخادم إكمال الإعداد.")
    return AsyncOpenAI(api_key=key)

def get_public_base_url() -> str:
    base = os.getenv("PUBLIC_BASE_URL", "").rstrip("/")
    if not base.startswith("https://"):
        raise HTTPException(status_code=503, detail="عنوان HTTPS العام للخادم غير مضبوط.")
    return base

async def create_image(client: AsyncOpenAI, prompt: str, public_base_url: str) -> str:
    model = os.getenv("OPENAI_IMAGE_MODEL", "gpt-image-2.5-flare")
    result = await client.images.generate(
        model=model, prompt=prompt, size="1024x1024", quality="high",
        n=1, output_format="png", moderation="auto",
    )
    encoded = result.data[0].b64_json
    if not encoded:
        raise RuntimeError("OpenAI returned no image data")
    image_bytes = base64.b64decode(encoded, validate=True)
    filename = f"{uuid.uuid4().hex}.png"
    (GENERATED_DIR / filename).write_bytes(image_bytes)
    return f"{public_base_url}/generated/{filename}"

@app.get("/health")
async def health():
    return {"status": "ok", "openai_configured": bool(os.getenv("OPENAI_API_KEY"))}

@app.post("/generate", response_model=GenerateResponse)
async def generate_image(payload: GenerateRequest, request: Request):
    enforce_rate_limit(request.client.host if request.client else "unknown")
    try:
        public_base_url = get_public_base_url()
        client = get_client()
        prompt = (f"Create one high-quality image in this visual style: {payload.style}. "
                  f"Image description: {payload.prompt}. Strong composition, polished details.")
        return GenerateResponse(image_url=await create_image(client, prompt, public_base_url))
    except HTTPException:
        raise
    except Exception as exc:
        print(f"Image generation failed: {type(exc).__name__}: {exc}")
        raise HTTPException(status_code=502, detail="تعذر إنشاء الصورة حالياً. تحقق من إعدادات خدمة الصور أو حاول لاحقاً.") from exc

@app.post("/generate-manga", response_model=MangaResponse)
async def generate_manga(payload: MangaRequest, request: Request):
    enforce_rate_limit(request.client.host if request.client else "unknown")
    try:
        client = get_client()
        public_base_url = get_public_base_url()
        urls: list[str] = []
        for page_number in range(1, payload.page_count + 1):
            page_prompt = (
                "Create ONE complete manga comic page, portrait-oriented page composition inside a square canvas. "
                "Use clear black ink line art, screentones, expressive faces, clean panel borders, dynamic but readable layouts. "
                "Use 3 to 5 distinct panels. Leave speech balloons EMPTY with no letters, no words, no watermark, "
                "so the reader can add Arabic dialogue later. Maintain the exact same character design, clothing, hairstyle, "
                "colors/tones and proportions across every page. Do not add extra main characters unless the story requires them. "
                f"Manga style: {payload.style}. Main character design: {payload.character}. "
                f"Full story context: {payload.story}. This is page {page_number} of {payload.page_count}; "
                "show the next coherent story beat in sequence, with visual continuity from previous pages. "
                "Do not make a cover unless this is page 1 and the story explicitly asks for one."
            )
            urls.append(await create_image(client, page_prompt, public_base_url))
        return MangaResponse(pages=urls)
    except HTTPException:
        raise
    except Exception as exc:
        print(f"Manga generation failed: {type(exc).__name__}: {exc}")
        raise HTTPException(status_code=502, detail="تعذر إنشاء صفحات المانجا كاملة. حاول بعد قليل أو قلّل عدد الصفحات.") from exc
