package com.artai.app

import android.os.Bundle
import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Ink = Color(0xFF100D1C)
private val Panel = Color(0xFF1D1830)
private val Violet = Color(0xFF9B7BFF)
private val Muted = Color(0xFFB8AECF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ArtAiScreen() }
    }
}

@Composable
fun ArtAiScreen() {
    var mode by remember { mutableStateOf("صورة") }
    var prompt by remember { mutableStateOf("") }
    var character by remember { mutableStateOf("") }
    var style by remember { mutableStateOf("واقعي") }
    var pageCount by remember { mutableStateOf(3) }
    var imageUrl by remember { mutableStateOf<String?>(null) }
    var mangaPages by remember { mutableStateOf<List<String>>(emptyList()) }
    var status by remember { mutableStateOf("اكتب وصف الصورة أو قصة المانجا") }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current
    val styles = listOf("واقعي", "أنمي", "مانجا أبيض وأسود", "مانجا ملونة", "ثلاثي الأبعاد", "Pixel Art", "كرتوني", "لوحة زيتية")

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Violet, background = Ink, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            modifier = Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF211638), Ink)))
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(18.dp))
            Icon(Icons.Default.AutoAwesome, null, tint = Violet, modifier = Modifier.size(42.dp))
            Text("ART AI", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text("ارسم أفكارك واصنع مانجتك", color = Muted, fontSize = 15.sp)
            Spacer(Modifier.height(22.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("صورة", "مانجا").forEach { option ->
                    FilterChip(
                        selected = mode == option,
                        onClick = { mode = option; imageUrl = null; mangaPages = emptyList() },
                        label = { Text(if (option == "مانجا") "صناعة مانجا" else "إنشاء صورة") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            Spacer(Modifier.height(14.dp))

            Card(colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(17.dp)) {
                    Text(if (mode == "مانجا") "قصة المانجا" else "صف الصورة التي تريدها",
                        fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(9.dp))
                    OutlinedTextField(
                        value = prompt, onValueChange = { prompt = it },
                        modifier = Modifier.fillMaxWidth(), minLines = if (mode == "مانجا") 5 else 4,
                        placeholder = { Text(if (mode == "مانجا") "مثال: فتى يكتشف قناعاً سحرياً، وكل قناع يمنحه قوة مختلفة..." else "مثال: محارب خيالي يقف فوق جبل وقت الغروب...") },
                        shape = RoundedCornerShape(14.dp)
                    )
                    if (mode == "مانجا") {
                        Spacer(Modifier.height(13.dp))
                        Text("وصف الشخصية الرئيسية", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(7.dp))
                        OutlinedTextField(
                            value = character, onValueChange = { character = it },
                            modifier = Modifier.fillMaxWidth(), minLines = 2,
                            placeholder = { Text("الشكل، الشعر، الملابس، العمر التقريبي، والسمات المميزة...") },
                            shape = RoundedCornerShape(14.dp)
                        )
                        Spacer(Modifier.height(13.dp))
                        Text("عدد الصفحات")
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            (1..4).forEach { count ->
                                FilterChip(selected = pageCount == count, onClick = { pageCount = count },
                                    label = { Text("$count") })
                            }
                        }
                        Text("كل صفحة تتكون من عدة إطارات مانجا وفق أحداث القصة.", color = Muted, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(15.dp))
                    Text("أسلوب الرسم", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(7.dp))
                    var expanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(style)
                        }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            styles.forEach { item ->
                                DropdownMenuItem(text = { Text(item) }, onClick = { style = item; expanded = false })
                            }
                        }
                    }
                    Spacer(Modifier.height(17.dp))
                    Button(
                        onClick = {
                            val valid = if (mode == "مانجا") prompt.isNotBlank() && character.isNotBlank() else prompt.isNotBlank()
                            if (!valid) {
                                status = if (mode == "مانجا") "اكتب القصة ووصف الشخصية أولاً" else "اكتب وصفاً للصورة أولاً"
                            } else {
                                scope.launch {
                                    loading = true
                                    imageUrl = null
                                    mangaPages = emptyList()
                                    status = if (mode == "مانجا") "جارٍ إنشاء صفحات المانجا... قد يستغرق ذلك بعض الوقت" else "جارٍ إنشاء الصورة..."
                                    try {
                                        if (mode == "مانجا") {
                                            mangaPages = requestManga(prompt, character, style, pageCount)
                                            status = "اكتملت صفحات المانجا (${mangaPages.size})"
                                        } else {
                                            imageUrl = requestImage(prompt, style)
                                            status = "تم إنشاء الصورة بنجاح"
                                        }
                                    } catch (error: Exception) {
                                        status = error.message ?: "تعذر الإنشاء. تحقق من اتصالك وإعداد الخادم."
                                    } finally {
                                        loading = false
                                    }
                                }
                            }
                        },
                        enabled = !loading,
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape = RoundedCornerShape(15.dp)
                    ) {
                        if (loading) CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                        else Icon(Icons.Default.AutoAwesome, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (loading) "جارٍ الإنشاء..." else if (mode == "مانجا") "أنشئ المانجا" else "ارسم الصورة", fontSize = 16.sp)
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(15.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Image, null, tint = Violet)
                        Spacer(Modifier.width(8.dp))
                        Text(if (mode == "مانجا") "صفحات المانجا" else "نتيجة الصورة", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    if (imageUrl != null) {
                        AsyncImage(model = imageUrl, contentDescription = "الصورة المنشأة",
                            modifier = Modifier.fillMaxWidth().heightIn(min = 180.dp, max = 440.dp))
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = {
                            val url = imageUrl!!
                            scope.launch {
                                status = "جارٍ حفظ الصورة..."
                                status = runCatching { withContext(Dispatchers.IO) { saveImageToGallery(context, url) }; "تم حفظ الصورة في المعرض" }
                                    .getOrElse { "تعذر حفظ الصورة: ${it.message ?: "خطأ غير معروف"}" }
                            }
                        }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.SaveAlt, null); Spacer(Modifier.width(7.dp)); Text("حفظ في المعرض")
                        }
                    } else if (mangaPages.isNotEmpty()) {
                        mangaPages.forEachIndexed { index, page ->
                            Text("الصفحة ${index + 1}", color = Violet, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            AsyncImage(model = page, contentDescription = "صفحة مانجا ${index + 1}",
                                modifier = Modifier.fillMaxWidth().heightIn(min = 220.dp, max = 480.dp))
                            OutlinedButton(onClick = {
                                scope.launch {
                                    status = "جارٍ حفظ الصفحة ${index + 1}..."
                                    status = runCatching { withContext(Dispatchers.IO) { saveImageToGallery(context, page) }; "تم حفظ الصفحة ${index + 1} في المعرض" }
                                        .getOrElse { "تعذر حفظ الصفحة: ${it.message ?: "خطأ غير معروف"}" }
                                }
                            }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.SaveAlt, null); Spacer(Modifier.width(7.dp)); Text("حفظ الصفحة ${index + 1}")
                            }
                            Spacer(Modifier.height(16.dp))
                        }
                    } else {
                        Box(Modifier.fillMaxWidth().height(170.dp)
                            .background(Color(0xFF29223D), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Image, null, tint = Muted, modifier = Modifier.size(42.dp))
                                Text("ستظهر النتيجة هنا", color = Muted)
                            }
                        }
                    }
                    Spacer(Modifier.height(9.dp))
                    Text(status, color = Muted, fontSize = 13.sp)
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("ART AI • الصور والمانجا بالذكاء الاصطناعي", color = Muted, fontSize = 12.sp)
        }
    }
}

private suspend fun requestImage(prompt: String, style: String): String = withContext(Dispatchers.IO) {
    val response = postJson("/generate", JSONObject().put("prompt", prompt.trim()).put("style", style))
    response.optString("image_url").also { require(it.startsWith("https://")) { "استجابة الخادم لا تحتوي على رابط صورة HTTPS صالح." } }
}

private suspend fun requestManga(story: String, character: String, style: String, pageCount: Int): List<String> = withContext(Dispatchers.IO) {
    val response = postJson("/generate-manga", JSONObject()
        .put("story", story.trim()).put("character", character.trim())
        .put("style", style).put("page_count", pageCount))
    val pages = response.optJSONArray("pages") ?: JSONArray()
    (0 until pages.length()).map { pages.getString(it) }.also { list ->
        require(list.isNotEmpty() && list.all { it.startsWith("https://") }) { "لم يستلم التطبيق صفحات مانجا صالحة من الخادم." }
    }
}

private fun postJson(path: String, body: JSONObject): JSONObject {
    val baseUrl = BuildConfig.ART_AI_API_BASE_URL.trimEnd('/')
    require(!baseUrl.contains("YOUR-BACKEND")) {
        "لم يتم إعداد عنوان خادم ART AI بعد. أضف ART_AI_API_BASE_URL في إعدادات Gradle."
    }
    val connection = URL("$baseUrl$path").openConnection() as HttpURLConnection
    try {
        connection.requestMethod = "POST"
        connection.connectTimeout = 20000
        connection.readTimeout = 600000
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val responseText = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        val response = runCatching { JSONObject(responseText) }.getOrNull()
        if (code !in 200..299) {
            val detail = response?.optString("detail")?.takeIf { it.isNotBlank() && it != "null" }
            throw IllegalStateException(detail ?: "فشل الخادم (HTTP $code)")
        }
        return response ?: throw IllegalStateException("استجابة الخادم غير مفهومة.")
    } finally {
        connection.disconnect()
    }
}


private fun saveImageToGallery(context: Context, imageUrl: String) {
    require(Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) { "حفظ الصور في المعرض يتطلب Android 10 أو أحدث في هذه النسخة." }
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "ART_AI_${System.currentTimeMillis()}.png")
        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ART AI")
        put(MediaStore.Images.Media.IS_PENDING, 1)
    }
    val resolver = context.contentResolver
    val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        ?: throw IllegalStateException("لم يمكن إنشاء ملف في المعرض")
    try {
        val connection = URL(imageUrl).openConnection()
        connection.connectTimeout = 20000
        connection.readTimeout = 120000
        connection.getInputStream().use { input ->
            resolver.openOutputStream(uri)?.use { output -> input.copyTo(output) }
                ?: throw IllegalStateException("تعذر فتح ملف الحفظ")
        }
        val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
        resolver.update(uri, done, null, null)
    } catch (error: Exception) {
        resolver.delete(uri, null, null)
        throw error
    }
}
